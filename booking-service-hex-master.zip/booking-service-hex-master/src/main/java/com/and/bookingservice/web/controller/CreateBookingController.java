package com.and.bookingservice.web.controller;

import com.and.bookingservice.core.exception.BookingException;
import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.port.in.MakeBookingUseCase;
import com.and.bookingservice.web.converter.BookingRequestToBookingConverter;
import com.and.bookingservice.web.converter.BookingToBookingCreatedConvertor;
import com.and.bookingservice.web.request.BookingRequest;
import com.and.bookingservice.web.response.BookingCreatedResponse;
import com.and.bookingservice.web.response.ErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
@RequestMapping("/bookings")
@AllArgsConstructor
@Slf4j
public class CreateBookingController {

    private final BookingRequestToBookingConverter bookingRequestToBookingConverter;
    private final BookingToBookingCreatedConvertor bookingToBookingCreatedConverter;

    private final MakeBookingUseCase makeBookingUseCase;

    @Operation(summary = "Create a Booking")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "201",
                            description = "Booking created",
                            content = {
                                    @Content(
                                            mediaType = "application/json",
                                            schema = @Schema(implementation = BookingCreatedResponse.class))
                            }),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Bad request",
                            content = {
                                    @Content(
                                            mediaType = "application/json",
                                            schema = @Schema(implementation = ErrorResponse.class))
                            })
            })
    @PostMapping()
    public BookingCreatedResponse createPerson(@RequestBody @Valid BookingRequest request) {
        Booking bookingToCreate = bookingRequestToBookingConverter.convert(request);
        if (Objects.isNull(bookingToCreate)) {
            throw new BookingException.BadRequest("Invalid booking");
        }
        Booking created = makeBookingUseCase.makeBooking(bookingToCreate);
        return bookingToBookingCreatedConverter.convert(created);
    }

}
