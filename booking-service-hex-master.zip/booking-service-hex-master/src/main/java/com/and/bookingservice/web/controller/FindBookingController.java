package com.and.bookingservice.web.controller;

import com.and.bookingservice.core.exception.BookingException;
import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.port.in.FindBookingsUseCase;
import com.and.bookingservice.web.response.BookingSearchResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/bookings")
@AllArgsConstructor
@Slf4j
public class FindBookingController {

    private final FindBookingsUseCase findBookingsUseCase;

    @Operation(summary = "Get Bookings for a specific date")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Fetched bookings",
                            content = {
                                    @Content(
                                            mediaType = "application/json",
                                            schema = @Schema(implementation = BookingSearchResponse.class))
                            }),
                    @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)
            })
    @GetMapping
    public BookingSearchResponse fetchBookings(@RequestParam(name = "date")
                                                   @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        log.info("Fetching bookings for date {}", date);
        List<Booking> bookings = findBookingsUseCase.fetchByDate(date);
        log.info("Found {} bookings for date {}", bookings.size(), date);
        return BookingSearchResponse.builder()
                .bookings(bookings)
                .build();
    }

    @Operation(summary = "Get the Booking for a given bookingId")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Found bookings",
                            content = {
                                    @Content(
                                            mediaType = "application/json",
                                            schema = @Schema(implementation = Booking.class))
                            }),
                    @ApiResponse(responseCode = "404", description = "Booking not found", content = @Content)
            })
    @GetMapping("/{bookingId}")
    public Booking fetchSingleBooking(@PathVariable String bookingId) {
        log.info("Fetching bookings for id {}", bookingId);
        Optional<Booking> booking = findBookingsUseCase.fetchBooking(bookingId);
        if (booking.isEmpty()) {
            throw new BookingException.ResourceNotFound("No booking found with id=" + bookingId);
        }
        return booking.get();
    }

}
