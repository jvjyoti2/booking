package com.and.bookingservice.web.response;

import com.and.bookingservice.core.model.Booking;
import lombok.Builder;
import lombok.Data;

import java.util.Collections;
import java.util.List;

@Data
@Builder
public class BookingSearchResponse {

    @Builder.Default
    private final List<Booking> bookings = Collections.emptyList();

}
