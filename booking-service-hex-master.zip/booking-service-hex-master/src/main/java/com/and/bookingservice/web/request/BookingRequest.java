package com.and.bookingservice.web.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

import java.time.LocalDate;

@Data
@Builder
@Jacksonized
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookingRequest {

    @NotBlank(message = "must not be empty")
    private String userId;

    @NotBlank(message = "must not be empty")
    private String resourceId;

    @TodayOrFuture
    private LocalDate bookingDate;

    @NotBlank(message = "must not be empty")
    private String duration;
}
