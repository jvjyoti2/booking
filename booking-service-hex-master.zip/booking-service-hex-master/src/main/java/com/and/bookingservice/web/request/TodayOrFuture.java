package com.and.bookingservice.web.request;

import jakarta.validation.*;

import java.lang.annotation.*;
import java.time.*;
import java.time.temporal.*;

@Target( { ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = TodayOrFutureValidator.class)
@Documented
public @interface TodayOrFuture {
    String message() default "date is not equal to today or in the future";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}

class TodayOrFutureValidator implements ConstraintValidator<TodayOrFuture, Temporal> {

    @Override
    public void initialize(TodayOrFuture constraintAnnotation) {
        // keep empty
    }

    @Override
    public boolean isValid(Temporal value, ConstraintValidatorContext context) {
        if (value == null) {
            return false;
        }

        return !LocalDate.from(value).isBefore(LocalDate.now());
    }

}
