package com.and.bookingservice.port.in;

import com.and.bookingservice.core.model.Booking;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface FindBookingsUseCase {

    List<Booking> fetchByDate(LocalDate date);

    Optional<Booking> fetchBooking(String bookingId);

}
