package com.and.bookingservice.web.controlleradvice;

import com.and.bookingservice.core.exception.BookingException;
import com.and.bookingservice.web.response.ErrorResponse;
import com.and.bookingservice.web.response.ErrorType;
import com.and.bookingservice.web.response.ValidationError;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Collections;
import java.util.List;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    public static final String ERR_MSG_UNKNOWN = "Unknown error occurred.";
    public static final String ERR_MSG_VALIDATION = "There are validation failures.";

    @ExceptionHandler(BookingException.ResourceNotFound.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(
            BookingException.ResourceNotFound exception) {
        return errorResponse(exception.getMessage(), ErrorType.BOOKING_NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationErrors(
            MethodArgumentNotValidException exception) {
        List<ValidationError> errors =
                exception.getBindingResult().getFieldErrors().stream()
                        .map(this::getValidationError)
                        .toList();
        return errorResponse(
                ERR_MSG_VALIDATION, ErrorType.VALIDATION_FAILED, errors, HttpStatus.BAD_REQUEST);
    }

    private ValidationError getValidationError(FieldError error) {
        return ValidationError.builder()
                .field(error.getField())
                .description(
                        StringUtils.isNotBlank(error.getDefaultMessage())
                                ? error.getDefaultMessage()
                                : ERR_MSG_UNKNOWN)
                .build();
    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<ErrorResponse> handleGeneralExceptions(Exception ex) {
        log.error("global caught exception handler", ex);

        return errorResponse(ex.getMessage());
    }

    @ExceptionHandler(RuntimeException.class)
    public final ResponseEntity<ErrorResponse> handleRuntimeExceptions(RuntimeException ex) {
        log.error("global runtime exception handler", ex);
        return errorResponse(ex.getMessage());
    }

    private ResponseEntity<ErrorResponse> errorResponse(String errorMessage) {
        return errorResponse(errorMessage, ErrorType.UNKNOWN_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private ResponseEntity<ErrorResponse> errorResponse(
            String errorMessage, ErrorType errorType, HttpStatus httpStatus) {
        return errorResponse(errorMessage, errorType, Collections.emptyList(), httpStatus);
    }

    private ResponseEntity<ErrorResponse> errorResponse(
            String errorMessage,
            ErrorType errorType,
            List<ValidationError> validationErrors,
            HttpStatus httpStatus) {
        ErrorResponse errorResponse = ErrorResponse.builder()
                        .message(StringUtils.isNotBlank(errorMessage) ? errorMessage : ERR_MSG_UNKNOWN)
                        .errorType(errorType)
                        .validationErrors(validationErrors)
                        .errorType(errorType)
                        .build();

        return new ResponseEntity<>(errorResponse, new HttpHeaders(), httpStatus);
    }
}
