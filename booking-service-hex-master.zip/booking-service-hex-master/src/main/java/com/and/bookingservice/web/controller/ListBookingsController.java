package com.and.bookingservice.web.controller;

import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.port.in.ListBookingsUseCase;
import com.and.bookingservice.web.response.BookingSearchResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/bookings")
@AllArgsConstructor
@Slf4j
public class ListBookingsController {

    private final ListBookingsUseCase listBookingsUseCase;

    @Operation(summary = "Get all Bookings")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Fetched bookings",
                            content = {
                                    @Content(
                                            mediaType = "application/json",
                                            schema = @Schema(implementation = BookingSearchResponse.class))
                            })
            })
    @GetMapping("/all")
    public BookingSearchResponse fetchAllBookings() {
        log.info("Fetching all bookings");
        List<Booking> bookings = listBookingsUseCase.fetchAll();
        log.info("Found {} bookings", bookings.size());
        return BookingSearchResponse.builder()
                .bookings(bookings)
                .build();
    }

}
