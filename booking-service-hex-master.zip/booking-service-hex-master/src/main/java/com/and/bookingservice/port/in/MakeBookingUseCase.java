package com.and.bookingservice.port.in;

import com.and.bookingservice.core.model.Booking;

public interface MakeBookingUseCase {

    Booking makeBooking(Booking bookingToCreate);

}
