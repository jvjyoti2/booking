package com.and.bookingservice.port.in;

import com.and.bookingservice.core.model.Booking;

public interface UpdateBookingUseCase {

    Booking updateBooking(Booking bookingToUpdate);

    void removeBooking(Booking bookingToRemove);

}
