package com.and.bookingservice.web.converter;

import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.web.response.BookingCreatedResponse;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class BookingToBookingCreatedConvertor implements Converter<Booking, BookingCreatedResponse> {

    @Override
    public BookingCreatedResponse convert(Booking source) {
        return BookingCreatedResponse.builder()
                .bookingId(source.getBookingId())
                .userId(source.getUserId())
                .resourceId(source.getResourceId())
                .bookingDate(source.getBookingDate())
                .duration(source.getDuration())
                .build();
    }

}
