package com.and.bookingservice.core.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class Booking {

    private String bookingId;
    private String userId;
    private String resourceId;
    private LocalDate bookingDate;
    private String duration;
}
