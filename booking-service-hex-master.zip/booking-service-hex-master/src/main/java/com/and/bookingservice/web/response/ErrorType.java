package com.and.bookingservice.web.response;

public enum ErrorType {
    VALIDATION_FAILED,
    BOOKING_NOT_FOUND,
    UNKNOWN_ERROR;
}
