package com.and.bookingservice.adapters.persistence;

import com.and.bookingservice.core.model.Booking;
import org.springframework.stereotype.Component;

@Component
public class BookingMapper {

    Booking mapToDomainMapper(BookingEntity entity) {
        return Booking.builder()
                .bookingId(entity.getBookingId().toString())
                .userId(entity.getUserId())
                .resourceId(entity.getResourceId())
                .bookingDate(entity.getBookingDate())
                .duration(entity.getDuration())
                .build();
    }

    public BookingEntity mapToCreateEntity(Booking booking) {
        return new BookingEntity(null,
                booking.getUserId(),
                booking.getResourceId(),
                booking.getBookingDate(),
                booking.getDuration()
        );
    }
}
