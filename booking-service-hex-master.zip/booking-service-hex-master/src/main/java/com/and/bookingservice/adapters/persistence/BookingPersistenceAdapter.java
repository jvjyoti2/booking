package com.and.bookingservice.adapters.persistence;

import com.and.bookingservice.core.exception.BookingException;
import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.port.out.FindBookings;
import com.and.bookingservice.port.out.ListBookings;
import com.and.bookingservice.port.out.MakeBooking;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@RequiredArgsConstructor
@Component
public class BookingPersistenceAdapter implements ListBookings, FindBookings, MakeBooking {

    private final BookingsRepository bookingsRepository;

    private final BookingMapper bookingMapper;

    @Override
    public List<Booking> fetchAll() {
        return bookingsRepository.findAll().stream()
                .map(bookingMapper::mapToDomainMapper)
                .toList();
    }

    @Override
    public List<Booking> findBookingsByDate(LocalDate date) {
        return bookingsRepository.findByBookingDate(date).stream()
                .map(bookingMapper::mapToDomainMapper)
                .toList();
    }

    @Override
    public Booking findBookingById(String bookingId) {
        return bookingsRepository.findById(Long.parseLong(bookingId))
                .map(bookingMapper::mapToDomainMapper)
                .orElseThrow(() -> new BookingException.ResourceNotFound("Booking not found"));
    }

    @Override
    public Booking create(Booking booking) {
        return bookingMapper.mapToDomainMapper(bookingsRepository.save(bookingMapper.mapToCreateEntity(booking)));
    }
}
