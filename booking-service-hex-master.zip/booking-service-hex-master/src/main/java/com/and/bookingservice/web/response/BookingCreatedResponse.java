package com.and.bookingservice.web.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class BookingCreatedResponse {

    private String bookingId;
    private String userId;
    private String resourceId;
    private LocalDate bookingDate;
    private String duration;

}
