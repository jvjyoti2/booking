package com.and.bookingservice.core.exception;

public class BookingException extends RuntimeException {

    public BookingException(String errorMessage) {
        super(errorMessage);
    }

    public static final class ResourceNotFound extends BookingException {
        public ResourceNotFound(String errorMessage) {
            super(errorMessage);
        }
    }

    public static final class BadRequest extends BookingException {
        public BadRequest(String errorMessage) {
            super(errorMessage);
        }
    }

}
