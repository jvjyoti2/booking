package com.and.bookingservice.port.in;

import com.and.bookingservice.core.model.Booking;

import java.util.List;

public interface ListBookingsUseCase {

    List<Booking> fetchAll();

}
