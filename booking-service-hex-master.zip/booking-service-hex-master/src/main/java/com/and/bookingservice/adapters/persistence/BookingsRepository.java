package com.and.bookingservice.adapters.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public interface BookingsRepository extends JpaRepository<BookingEntity, Long> {

    List<BookingEntity> findByBookingDate(LocalDate date);

    @Override
    Optional<BookingEntity> findById(Long bookingId);

}
