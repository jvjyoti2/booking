package com.and.bookingservice.service;

import com.and.bookingservice.adapters.persistence.BookingPersistenceAdapter;
import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.port.in.FindBookingsUseCase;
import com.and.bookingservice.port.in.ListBookingsUseCase;
import com.and.bookingservice.port.in.MakeBookingUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BookingsService implements ListBookingsUseCase, FindBookingsUseCase, MakeBookingUseCase {

    private final BookingPersistenceAdapter bookingPersistenceAdapter;

    @Override
    public List<Booking> fetchAll() {
        return bookingPersistenceAdapter.fetchAll();
    }

    @Override
    public List<Booking> fetchByDate(LocalDate date) {
        return bookingPersistenceAdapter.findBookingsByDate(date);
    }

    @Override
    public Optional<Booking> fetchBooking(String bookingId) {
        return Optional.ofNullable(bookingPersistenceAdapter.findBookingById(bookingId));
    }

    @Override
    public Booking makeBooking(Booking bookingToCreate) {
        return bookingPersistenceAdapter.create(bookingToCreate);
    }

}
