package com.and.bookingservice.web.converter;

import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.web.request.BookingRequest;
import jakarta.validation.Valid;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class BookingRequestToBookingConverter implements Converter<BookingRequest, Booking> {

    @Override
    public Booking convert(@Valid BookingRequest source) {
        return Booking.builder()
                .userId(source.getUserId())
                .resourceId(source.getResourceId())
                .bookingDate(source.getBookingDate())
                .duration(source.getDuration())
                .build();
    }

}
