package com.and.bookingservice.web.converter;

import com.and.bookingservice.web.request.BookingRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

class BookingRequestToBookingConverterTests {

    private final BookingRequestToBookingConverter converter = new BookingRequestToBookingConverter();

    @Test
    void nullInputShouldThrowException() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            converter.convert(null);
        });
    }

    @Test
    void emptyInputShouldThrowException() {
        BookingRequest bookingRequest = BookingRequest.builder().build();


            converter.convert(bookingRequest);

    }

}
