package com.and.bookingservice.core.service;

public class HardcodedBookingServiceTests {
}
