package com.and.bookingservice.web.controller;

import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.port.in.ListBookingsUseCase;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsEmptyCollection.empty;
import static org.hamcrest.core.IsIterableContaining.hasItem;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListBookingsControllerTests {

    private static final LocalDate BOOKING_ONE_DATE = LocalDate.of(2023, 9, 12);
    private static final LocalDate BOOKING_TWO_DATE = LocalDate.of(2023, 9, 13);

    private static final Booking BOOKING_ONE = Booking.builder()
            .bookingId("1")
            .userId("John")
            .resourceId("A1")
            .bookingDate(BOOKING_ONE_DATE)
            .duration("AM")
            .build();

    private static final Booking BOOKING_TWO = Booking.builder()
            .bookingId("2")
            .userId("Mary")
            .resourceId("A2")
            .bookingDate(BOOKING_TWO_DATE)
            .duration("FD")
            .build();

    @Mock
    private ListBookingsUseCase bookingsService;

    @InjectMocks
    private ListBookingsController listBookingController;

    @Test
    void canReturnEmptyList() {
        when(bookingsService.fetchAll()).thenReturn(Collections.emptyList());

        var response = listBookingController.fetchAllBookings();

        assertThat(response.getBookings(), empty());
    }

    @Test
    void canReturnSingleBookingAsList() {
        when(bookingsService.fetchAll()).thenReturn(List.of(BOOKING_ONE));

        var response = listBookingController.fetchAllBookings();

        assertThat(response.getBookings(), hasItem(BOOKING_ONE));
    }

    @Test
    void canReturnMultipleBookingAsList() {
        when(bookingsService.fetchAll()).thenReturn(List.of(BOOKING_ONE, BOOKING_TWO));

        var response = listBookingController.fetchAllBookings();

        assertThat(response.getBookings(), hasItem(BOOKING_ONE));
        assertThat(response.getBookings(), hasItem(BOOKING_TWO));
    }
}
