package com.and.bookingservice.web.request;

import com.and.bookingservice.CustomLocalValidatorFactoryBean;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.assertj.core.api.Fail.fail;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.collection.IsEmptyCollection.empty;
import static org.junit.jupiter.api.Assertions.assertThrows;

class BookingRequestTests {

    private static Validator validator;

    private static final List<ConstraintValidator<?,?>> customConstraintValidators =
            Collections.singletonList(new TodayOrFutureValidator());
    private static final ValidatorFactory customValidatorFactory =
            new CustomLocalValidatorFactoryBean(customConstraintValidators);

    @BeforeAll
    public static void setupValidatorInstance() {
        validator = customValidatorFactory.getValidator();
    }

    @Test
    void nullInputShouldThrowException() {
        assertThrows(IllegalArgumentException.class, () -> validator.validate(null));
    }

    @Test
    void emptyRequestShouldReturnViolations() {
        BookingRequest request = BookingRequest.builder().build();

        var violations = validator.validate(request);

        assertThat(violations, is(not(empty())));
    }

    @Test
    void missingUserIdShouldReturnViolation() {
        BookingRequest request = BookingRequest.builder()
                .resourceId("A1")
                .bookingDate(LocalDate.of(2023, 9, 12))
                .duration("AM")
                .build();

        Set<ConstraintViolation<BookingRequest>> violations = validator.validate(request);

        assertHasViolationForProperty(violations, "userId");
    }

    @Test
    void missingBookingDateShouldReturnViolation() {
        BookingRequest request = BookingRequest.builder()
                .userId("John")
                .resourceId("A1")
                .duration("AM")
                .build();

        Set<ConstraintViolation<BookingRequest>> violations = validator.validate(request);

        assertHasViolationForProperty(violations, "bookingDate");
    }

    @Test
    void missingResourceIdShouldReturnViolation() {
        BookingRequest request = BookingRequest.builder()
                .userId("John")
                .bookingDate(LocalDate.of(2023, 9, 12))
                .duration("AM")
                .build();

        Set<ConstraintViolation<BookingRequest>> violations = validator.validate(request);

        assertHasViolationForProperty(violations, "resourceId");
    }

    @Test
    void missingDurationShouldReturnViolation() {
        BookingRequest request = BookingRequest.builder()
                .userId("John")
                .resourceId("A1")
                .bookingDate(LocalDate.of(2023, 9, 12))
                .build();

        Set<ConstraintViolation<BookingRequest>> violations = validator.validate(request);

        assertHasViolationForProperty(violations, "duration");
    }

    private void assertHasViolationForProperty(Set<ConstraintViolation<BookingRequest>> violations, String property) {
        AtomicBoolean found = new AtomicBoolean(false);
        violations.forEach(violation -> {
            if (violation.getPropertyPath().toString().equalsIgnoreCase(property)) {
                found.set(true);
            }
        });
        if (!found.get()) {
            fail("Expected violation for property " + property);
        }
    }

}
