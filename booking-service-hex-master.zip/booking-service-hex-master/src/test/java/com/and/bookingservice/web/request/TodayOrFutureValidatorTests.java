package com.and.bookingservice.web.request;

import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TodayOrFutureValidatorTests {

    private final ConstraintValidatorContext IGNORED_CONTEXT = null;

    private final TodayOrFutureValidator validator = new TodayOrFutureValidator();

    @Test
    void nullWillReturnFalse() {
        assertFalse(validator.isValid(null, IGNORED_CONTEXT));
    }

    @Test
    void todayWillReturnTrue() {
        LocalDate today = LocalDate.now();

        assertTrue(validator.isValid(today, IGNORED_CONTEXT));
    }

    @Test
    void yesterdayWillReturnFalse() {
        LocalDate yesterday = LocalDate.now().minusDays(1);

        assertFalse(validator.isValid(yesterday, IGNORED_CONTEXT));
    }

    @Test
    void tomorrowWillReturnTrue() {
        LocalDate tomorrow = LocalDate.now().plusDays(1);

        assertTrue(validator.isValid(tomorrow, IGNORED_CONTEXT));
    }
}
