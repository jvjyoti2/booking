package com.and.bookingservice.web.controller;

import com.and.bookingservice.core.model.Booking;
import com.and.bookingservice.port.in.FindBookingsUseCase;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsEmptyCollection.empty;
import static org.hamcrest.core.IsIterableContaining.hasItem;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FindBookingControllerTests {

    private static final LocalDate ONE_DATE = LocalDate.of(2023, 9, 12);

    private static final Booking BOOKING_ONE = Booking.builder()
            .bookingId("1")
            .userId("John")
            .resourceId("A1")
            .bookingDate(ONE_DATE)
            .duration("AM")
            .build();

    private static final Booking BOOKING_TWO = Booking.builder()
            .bookingId("2")
            .userId("Mary")
            .resourceId("A2")
            .bookingDate(ONE_DATE)
            .duration("FD")
            .build();
    @Mock
    private FindBookingsUseCase bookingsService;

    @InjectMocks
    private FindBookingController findBookingController;


    @Nested
    class FindByDateTests {

        @Test
        void canReturnEmptyList() {
            when(bookingsService.fetchByDate(ONE_DATE)).thenReturn(Collections.emptyList());

            var response = findBookingController.fetchBookings(ONE_DATE);

            assertThat(response.getBookings(), empty());
        }

        @Test
        void canReturnSingleBookingAsList() {
            when(bookingsService.fetchByDate(ONE_DATE)).thenReturn(List.of(BOOKING_ONE));

            var response = findBookingController.fetchBookings(ONE_DATE);

            assertThat(response.getBookings(), hasItem(BOOKING_ONE));
        }

        @Test
        void canReturnMultipleBookingAsList() {
            when(bookingsService.fetchByDate(ONE_DATE)).thenReturn(List.of(BOOKING_ONE, BOOKING_TWO));

            var response = findBookingController.fetchBookings(ONE_DATE);

            assertThat(response.getBookings(), hasItem(BOOKING_ONE));
            assertThat(response.getBookings(), hasItem(BOOKING_TWO));
        }
    }

    @Nested
    class FindByIdTests {

    }

}
