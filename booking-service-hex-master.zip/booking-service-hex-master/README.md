# booking-service

Version of the Desk Booking Service following a Hexagon Architecture approach
